from pathlib import Path
p=Path('/tmp/randomx-deep-review-_ic3s9ua');repo=Path('/root/experiment/randomx-sp1')
(p/'loop-shim.cpp').write_text(r'''
#include <iostream>
#include <vector>
#include <new>
#include <cstring>
#include "virtual_machine.hpp"
#include "bytecode_machine.hpp"
#include "intrin_portable.h"
#include "allocator.hpp"
#define private public
#include "vm_interpreted.hpp"
#undef private
#define EXPORTED extern "C" __attribute__((visibility("default")))
using namespace randomx;
class LoopVm:public InterpretedVmDefault {
public:
 LoopVm(){scratchpad=(uint8_t*)AlignedAllocator<CacheLineSize>::allocMemory(ScratchpadSize);}
 void raw(const void* raw){memcpy(&program,raw,2176);initialize();execute();}
protected:
 void datasetPrefetch(uint64_t) override{}
 void datasetRead(uint64_t address,int_reg_t(&r)[RegistersCount]) override{
  // Same synthetic dataset as Rust VmMemory::no_memory; used solely to
  // isolate whole-iteration control/memory behavior from cache generation.
  uint64_t base=(address/64+1)*6364136223846793005ULL;
  uint64_t constants[]={0,9298411001130361340ULL,12065312585734608966ULL,9306329213124626780ULL,5281919268842080866ULL,10536153434571861004ULL,3398623926847679864ULL,9549104520008361294ULL};
  for(unsigned i=0;i<8;i++)r[i]^=base^constants[i];
 }
};
EXPORTED void* deep_loop_new(){return new LoopVm;}
EXPORTED void deep_loop_free(void* ptr){delete (LoopVm*)ptr;}
EXPORTED void deep_loop_run(void* ptr,const uint64_t* raw,uint8_t* scratch,uint8_t* regs,uint64_t* state,uint32_t* mode){
 auto* vm=(LoopVm*)ptr;auto saved=rx_get_rounding_mode();rx_set_rounding_mode(*mode);memcpy(vm->scratchpad,scratch,ScratchpadSize);vm->raw(raw);memcpy(scratch,vm->scratchpad,ScratchpadSize);memcpy(regs,&vm->reg,256);
 state[0]=vm->mem.mx;state[1]=vm->mem.ma;state[2]=vm->datasetOffset;state[3]=vm->config.readReg0;state[4]=vm->config.readReg1;state[5]=vm->config.readReg2;state[6]=vm->config.readReg3;state[7]=vm->config.eMask[0];state[8]=vm->config.eMask[1];*mode=rx_get_rounding_mode();rx_set_rounding_mode(saved);
}
''')
s=(repo/'randomx-sp1/src/lib.rs').read_text()
a=s.index('fn run(vm: &mut Vm, seed: &[m128i; 4]) {');b=s.index('\nfn init_vm(',a)
run=s[a:b].replace('fn run(vm: &mut Vm, seed: &[m128i; 4]) {\n    let bytes = gen_program_aes_4rx4(seed, 136);','pub fn review_run_raw(vm: &mut Vm, raw: &[u64;272]) {\n    let bytes:Vec<m128i> = raw.chunks_exact(2).map(|c|m128i::from_u64(c[1],c[0])).collect();')
assert run!=s[a:b]
(p/'probe/src/loop_sut.rs').write_text(s+'\n'+run)
(p/'probe/src/bin/vm_loop.rs').write_text(r'''
#[allow(dead_code,unexpected_cfgs)] #[path="../loop_sut.rs"] mod sut;
use randomx_deep_review::next;
use randomx_sp1_core::{new_vm,VmMemory};
use std::sync::Arc;
#[link(name="rxloop_deep")]
unsafe extern "C"{fn deep_loop_new()->*mut core::ffi::c_void;fn deep_loop_free(p:*mut core::ffi::c_void);fn deep_loop_run(p:*mut core::ffi::c_void,raw:*const u64,scratch:*mut u8,regs:*mut u8,state:*mut u64,mode:*mut u32);}
fn ins(op:u8,dst:u8,src:u8,modifier:u8,imm:u32)->u64{op as u64|((dst as u64)<<8)|((src as u64)<<16)|((modifier as u64)<<24)|((imm as u64)<<32)}
fn main(){unsafe{
 let ctx=deep_loop_new();let mut vm=new_vm(Arc::new(VmMemory::no_memory()));let mut rng=0xb76a2293e1237;let mut count=0;
 for pattern in 0..32 {for mode in 0..4 {
  let mut raw=[0u64;272];for e in &mut raw[..16] {*e=if pattern%4==0 {0}else if pattern%4==1 {u64::MAX}else{next(&mut rng)};}
  // Exercise identical scratchpad read/write lines, the final line, and all
  // dataset-offset endpoints while allowing memory-register mixing to vary.
  if pattern%4==0 {raw[8]=0;raw[10]=0;raw[13]=0;}
  if pattern%4==1 {raw[8]=u64::MAX;raw[10]=u32::MAX as u64;raw[13]=524287;}
  for (i,word) in raw[16..].iter_mut().enumerate(){
   let v=next(&mut rng);let dst=(i%8) as u8;let src=((i/8)%8) as u8;
   *word=match pattern%16 {
    0=>ins(0x4c,0,0,0,0), // IMUL_RCP with zero divisor: NOP
    1=>ins(0xac,0,src,0,0), // repeated E multiplication (overflow propagation)
    2=>ins(0xcc,0,src,0,v as u32), // repeated E division
    3=>ins(0xd0,0,0,0,0), // repeated E square root
    4=>ins(0xa6,0,0,0,0), // repeated exponent/sign XOR (including zero)
    5=>ins(if i%2==0{0xa6}else{0x7c},0,src,0,0), // scale and add
    6=>ins(if i%2==0{0x7c}else{0x91},dst,src,0,0), // add and subtract
    7=>ins(0xf0,dst,src,(v>>32) as u8,v as u32), // writes all scratchpad tiers
    8=>ins(0xd6,dst,0,(i as u8)<<4,v as u32), // consecutive branches
    9=>if i==255 {ins(0xd6,0,0,0,0x001fff7f)} else {ins(0xcc,0,0,0,0)}, // branch repeats long division block when condition allows
    10=>ins(if i%2==0{0xef}else{0xac},dst,src,0,v as u32), // frequent rounding changes
    11=>ins(0x17,dst,dst,0,v as u32), // immediate L3 loads
    12=>ins(0x78,dst,src,0,0), // swaps both float lanes
    13=>ins(0x00,5,src,(i as u8)<<2,v as u32), // displacement and integer wrap
    _=>v,
   };
  }
  for (i,w) in vm.scratchpad.iter_mut().enumerate(){*w=match pattern/8 {0=>0,1=>u64::MAX,2=>if i%2==0{0x7fffffff80000000}else{0x800000007fffffff},_=>next(&mut rng)};}
  if pattern%16==9 {raw[8]=0;raw[10]=0;vm.scratchpad[0]=0x180;}
  let mut scratch=vm.scratchpad.clone();let mut cregs=[0u8;256];let mut cs=[0u64;9];let mut cmode=mode;vm.set_rounding_mode(mode);
  deep_loop_run(ctx,raw.as_ptr(),scratch.as_mut_ptr().cast(),cregs.as_mut_ptr(),cs.as_mut_ptr(),&mut cmode);
  sut::review_run_raw(&mut vm,&raw);
  assert_eq!(cregs,vm.reg.to_bytes(),"register pattern={pattern} mode={mode}");
  assert_eq!(scratch,vm.scratchpad,"scratch pattern={pattern} mode={mode}");
  let rs=[vm.mem_reg.mx as u64,vm.mem_reg.ma as u64,vm.dataset_offset,vm.config.read_reg[0] as u64,vm.config.read_reg[1] as u64,vm.config.read_reg[2] as u64,vm.config.read_reg[3] as u64,vm.config.e_mask[0],vm.config.e_mask[1]];
  assert_eq!(cs,rs,"config pattern={pattern} mode={mode}");assert_eq!(cmode,vm.get_rounding_mode());count+=1;
 }println!("whole VM pattern={pattern} cumulative cases={count} matched");}
 deep_loop_free(ctx);vm.reset_rounding_mode();println!("PASS {count} complete 2048-iteration VM executions with crafted programs and synthetic dataset");
}}
''')
print('VM loop probe written; exact Rust source prefix plus copy of unchanged run loop with raw program injection')
