#!/usr/bin/env bash
set -euo pipefail
cd /tmp/randomx-canonical-review-cgtbetcx
cmake -S RandomX -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=ON
cmake --build build --target randomx --parallel 2
c++ -std=c++17 -O2 -DNDEBUG -maes -fPIC -shared shim.cpp -I RandomX/src -L build -Wl,-rpath,/tmp/randomx-canonical-review-cgtbetcx/build -lrandomx -o librxprobe.so
c++ -std=c++17 -O2 -DNDEBUG -maes -fPIC -shared aes-shim.cpp -I RandomX/src -L build -Wl,-rpath,/tmp/randomx-canonical-review-cgtbetcx/build -lrandomx -o librxaesprobe.so
cargo run --manifest-path probe/Cargo.toml --release --offline --no-default-features --bin generator
cargo run --manifest-path probe/Cargo.toml --release --offline --bin superscalar_exec
cargo run --manifest-path probe/Cargo.toml --release --offline --bin portable_aes
cargo run --manifest-path probe/Cargo.toml --release --offline --bin vm
cargo run --manifest-path probe/Cargo.toml --release --offline --features full-probe --bin fullhash -- --large-key
