
#include <cstdint>
#include <stdexcept>
namespace randomx {
struct ReviewGenerator {
 uint64_t state, calls=0, words=0, bytes=0; uint32_t mode;
 ReviewGenerator(uint64_t seed,uint32_t m):state(seed),mode(m){}
 uint64_t next(){if(++calls>1000000)throw std::runtime_error("RNG limit");state+=0x9e3779b97f4a7c15ULL;uint64_t z=state;z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;z=(z^(z>>27))*0x94d049bb133111ebULL;return z^(z>>31);}
 uint8_t getByte(){bytes++;auto v=next();return (mode>=8 && ((v>>32)&7)!=0) ? uint8_t(mode-8) : uint8_t(v);}
 uint32_t getUInt32(){words++;auto v=next();if(mode==0)return uint32_t(v);if(((v>>32)&7)==0)return uint32_t(v);switch(mode%8){case 0:return uint32_t(v&7);case 1:return 0;case 2:return 7;case 3:return 0xffffffff;case 4:return uint32_t(1)<<(v&31);case 5:return uint32_t(v&15);case 6:return 0x80000000;default:{uint32_t edge[]={0,1,2,3,7,8,0x7fffffff,0x80000000,0xfffffffe,0xffffffff};return edge[v%10];}}}
};
inline uint64_t review_events[12]={};
}
