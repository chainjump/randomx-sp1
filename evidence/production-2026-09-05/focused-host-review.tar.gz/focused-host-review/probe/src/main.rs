fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("argon" | "argon-negative-control") => randomx_sp1_argon2::focused_safety_probe(),
        Some("superscalar") => randomx_sp1_core::superscalar::focused_safety_probe(),
        Some("vm") => randomx_sp1::focused_safety_probe(),
        Some("branch") => randomx_sp1::focused_branch_probe(),
        _ => panic!("expected argon, superscalar or vm"),
    }
}
