#[allow(dead_code)] mod runtime;
use softfloat_wrapper::{Float,F64,RoundingMode as O};
#[no_mangle]
pub extern "C" fn review_fp(variant:u32,op:u32,a:u64,b:u64,mode:u32)->u64 {
    if variant==0 {
        use randomx_softfp::*;
        let m=RoundingMode::from_fprc(mode);
        match op {0=>add(a,b,m),1=>sub(a,b,m),2=>mul(a,b,m),3=>div(a,b,m),4=>sqrt(a,m),_=>panic!()}
    } else if variant==1 {
        use runtime::*;
        let m=RoundingMode::from_fprc(mode);
        match op {0=>add(a,b,m),1=>sub(a,b,m),2=>mul(a,b,m),3=>div(a,b,m),4=>sqrt(a,m),_=>panic!()}
    } else {
        let x=F64::from_bits(a);let y=F64::from_bits(b);
        let m=match mode {0=>O::TiesToEven,1=>O::TowardNegative,2=>O::TowardPositive,3=>O::TowardZero,_=>panic!()};
        match op {0=>x.add(y,m),1=>x.sub(y,m),2=>x.mul(y,m),3=>x.div(y,m),4=>x.sqrt(m),_=>panic!()}.to_bits()
    }
}
