# Focused floating-point and memory-safety review

Completed 2026-09-05 against `randomx-sp1` commit
`8e6d9c8c4cd2367e295edcfe89ff055fe1f7c7f1`, containing the correction in
`48e096823fd332076c2b5ab0e272beee27b2b473`.

**Result: no additional critical correctness or memory-safety issue found in
the production hashing path.** No implementation change was indicated by
this pass. This is a further review by the same assistant, with additional
checking methods; it is not independent third-party sign-off.

The scope was the custom floating-point implementation and every reachable
unsafe operation in the hashing crates, for standard RandomX parameters and
the specified 0–60-byte key domain on SP1. The demonstration EVM code was
excluded. Neither the SP1 guest nor a prover was built or run in this pass.
All new executable checks were isolated host programs.

The source review established the following:

- **Floating-point domain:** decoder register-use tracking prevents nested or
  overlapping branch loops. The constrained increment permits at most two
  consecutive taken branches, hence at most three executions of each
  instruction per iteration. E starts at least `2^-255`; at most 765
  divisions, each bounded below by a representable halving, keep it at least
  `2^-1020`. Positive infinity propagates through E operations without a
  zero divisor, zero multiplier, or negative square root. F cancellation,
  signed zero, and exponent toggling preserve normal-or-zero operands.
  An integer-only interval calculation confirms the upper bound
  `0x1.000000000001ap+432` through 768 arbitrary effects, excluding F
  infinity and NaN. Final F XOR E is used as bits and reset before subsequent
  arithmetic.
- **Directed rounding:** exact-sign comparisons, correction direction,
  cancellation, signed zero, overflow saturation, and scalar/vector paths
  were traced. Product coefficients occupy at most 106 bits. The addition
  path's 75-bit alignment fits u128; critically, at distance 75 the small
  operand is too small to round the larger coefficient across a binade,
  so aligning the nearest result cannot introduce a 129th bit. Smaller
  distances, cancellation, and mul/div/sqrt alignments also fit. Infinities
  are intercepted before finite magnitude decomposition.
- **Argon2:** the first two blocks are initialized before use. Every
  first-pass read addresses the initialized prefix. Every later-pass input
  is initialized and disjoint from the current writable block. All 128
  destination words and local MaybeUninit words are written before they
  are read. Shared inputs may alias each other safely. Box ownership,
  alignment, Block byte views, and conversion from uninitialized storage
  preserve the required invariants.
- **VM:** private decoding bounds integer and floating register offsets and
  prevents sentinel offsets from reaching register accesses. Scratchpad
  masks preserve alignment and allocation bounds, including eight-word
  iteration accesses. The public hash path checks the allocation length.
  Branch targets followed by the loop increment keep fetched PCs in
  `0..256`. Floating-point mode conversion receives only values in `0..4`.
- **Dataset and superscalar:** private cache/program construction preserves
  the relationship between allocation length and executable programs. Flat
  cache-word reads retain allocation provenance. All 100 pair-handler
  offsets are aligned and bounded; register operands are copied before
  writes, including aliased source/destination cases. Chunk and tail
  dispatch retain their correct pairing. Target-gated native AES/control
  assembly is excluded from SP1 and was also inspected for its pointer and
  feature preconditions.

New validation results:

| Check | Result |
| --- | --- |
| Exact unbounded-integer IEEE-754 oracle | 2,388,124 operation/input/mode cases, each checked through repository host arithmetic, the pinned public Succinct arithmetic source, and Berkeley SoftFloat: 7,164,372 matching bit comparisons |
| Full Argon2 index ranges | All 524,286 distinct first/later-pass block positions checked using intervals covering every 32-bit pseudo-random choice; initialization and destination non-aliasing bounds hold |
| Integer-only F interval calculation | No infinity or NaN reachable in the overapproximation through 768 effects; agrees with the previous floating-point interval bound |
| Miri: Argon2 and block views | 14 compressions into uninitialized destinations, 32 XOR-pass compressions, shared-input aliases, 2,048 flattened word reads, byte views and Box conversion: passed under Stacked Borrows and Tree Borrows |
| Miri: VM | 16,384 decoded effects covering all opcode/reduced-register pairs, boundary scratchpad accesses, and 256 full-program fetches: passed |
| Miri: backward branches | Crafted program executed 768 fetches with two taken branches to target -1 and exited at PC 256: passed |
| Miri: superscalar | 6,400 pairs covering all 100 handlers and every reduced source/destination pair, one generated program, and all chunk/tail lengths 0–65: passed |
| Miri negative control | Deliberately choosing the XOR compression path for an uninitialized destination in the harness correctly failed with an uninitialized-memory read |

The arithmetic matrix covers every finite-normal encoded exponent, seven
boundary fractions, exponent separations around cancellation, half-ULP, and
75/76-bit alignment boundaries, all four rounding modes, signed zeros, and
reachable infinity propagation. It is finite coverage, not an exhaustive
check of every 64-bit operand. The oracle skipped 152,652 per-mode cases
with exact nonzero subnormal results or zero divisors, which are outside
the reviewed RandomX arithmetic domain.

Miri used Rust `1.100.0-nightly (a69a63265 2026-09-03)`, strict provenance,
symbolic alignment, and its default validity/alias checks. The probes copied
the actual source, appending access wrappers. The sole replacement in the
Miri production source was the native floating-point-control assembly
function, which became a no-op; stored rounding-mode validation remained
intact. The compression probe used 16 blocks, not a complete 256 MiB cache.
The complete allocation/index argument was reviewed separately. Miri checks
the executions provided to it and does not establish universal soundness.
[Miri documentation](https://github.com/rust-lang/miri),
[Rust pointer and aliasing requirements](https://doc.rust-lang.org/reference/behavior-considered-undefined.html).

The floating-point probe compiled the repository helper directly and a copy
that substitutes only the nearest backend with public Succinct source:
`succinct-1.94.0-64bit`, commit
`c7149403db5f6f72f410d6dffcee90378235f23b`, compiler-builtins 0.1.160 and
portable libm 0.2.15. Debug assertions and integer overflow checks were
enabled. This does not establish identity with the installed SP1 toolchain
or validate its RISC-V code generation.

Source snapshots and the permitted substitutions were verified against
[16 source digests](source-sha256.json). The [preparation script](prepare.py),
[floating-point preparation](prepare_float.py), [exact arithmetic oracle](exact_float.py),
and [range checks](invariants.py) are retained in this temporary review
directory. Runtime source remains in the preceding temporary review
directory referenced by `prepare_float.py`. The scripts use absolute local
paths; they are review probes rather than a packaged CI test suite.

Logs: [arithmetic](exact-float.txt), [ranges](invariants.txt),
[Argon2 Miri](miri-argon.txt), [Argon2 Tree Borrows](miri-argon-tree.txt),
[VM Miri](miri-vm.txt), [branch Miri](miri-branch.txt),
[superscalar Miri](miri-superscalar.txt),
[deliberate negative control](miri-argon-negative.txt).

The remaining deployment validation is unchanged: reproducibly build the
actual production guest from the corrected source, check its outputs
against canonical RandomX, derive its verification key, and generate and
verify its proof. Application statement/input binding remains specific to
the consuming production application and was not established by this
hash-library review.
