fn main() {
    println!("cargo:rustc-link-search=native=/tmp/randomx-canonical-review-cgtbetcx");
    println!("cargo:rustc-link-lib=dylib=rxprobe");
    println!("cargo:rustc-link-arg=-Wl,-rpath,/tmp/randomx-canonical-review-cgtbetcx");
}
