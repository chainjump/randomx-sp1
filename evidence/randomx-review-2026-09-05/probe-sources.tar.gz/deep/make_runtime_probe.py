from pathlib import Path
import re
p=Path('/tmp/randomx-deep-review-_ic3s9ua');tc=p/'toolchain/library/compiler-builtins'
original=tc/'Cargo.toml'
if not (tc/'Cargo.original.toml').exists():original.rename(tc/'Cargo.original.toml')
original.write_text('[workspace]\nresolver="2"\nmembers=["builtins-shim","libm"]\n')
rp=p/'runtime-probe';(rp/'src').mkdir(parents=True,exist_ok=True)
(rp/'Cargo.toml').write_text('''[package]
name="randomx-runtime-review"
version="0.0.0"
edition="2024"
[workspace]
[dependencies]
compiler_builtins={path="../toolchain/library/compiler-builtins/builtins-shim",default-features=false,features=["mangled-names","no-asm","no-f16-f128"]}
libm={path="../toolchain/library/compiler-builtins/libm",default-features=false,features=["force-soft-floats"]}
softfloat-wrapper="=0.3.4"
''')
s=Path('/root/experiment/randomx-sp1/softfp/src/lib.rs').read_text()
a=s.index('#[cfg(target_arch = "riscv64")]');b=s.index('#[inline]\nfn add_inner',a)
nearest='mod nearest {\n'
for op in ['add','sub','mul','div']:
 nearest+=f'#[inline(always)] pub fn {op}(a:u64,b:u64)->u64 {{compiler_builtins::float::{op}::__{op}df3(f64::from_bits(a),f64::from_bits(b)).to_bits()}}\n'
nearest+='#[inline(always)] pub fn sqrt(a:u64)->u64 {libm::sqrt(f64::from_bits(a)).to_bits()}\n}\n'
(rp/'src/softfp.rs').write_text(s[:a]+nearest+s[b:])
main=Path('/tmp/randomx-sp1-fp-review-qix7n9vq/src/main.rs').read_text().replace('use randomx_softfp::','#[allow(dead_code)] mod softfp;\nuse softfp::')
main=main.replace('println!("{checked} arithmetic comparisons passed (targeted boundaries and 100000 random pairs).");','println!("PASS {checked} arithmetic comparisons using pinned toolchain integer helpers and portable sqrt, all four rounding modes");\n nearest_checks();')
main+=r'''
fn nearest_checks(){
 let mut state=0xa780a269e4b31a10;let mut checked=0u64;
 let mut special=vec![0,1,2,FRAC-1,FRAC,1<<52,(1<<52)+1,EXP-2,EXP-1,EXP];
 for e in 1..2047 {for f in [0,1,FRAC] {special.push(e<<52|f);}}
 for s in 0..2 {for &base in &special {let a=base|(s*SIGN);for bbase in [0,1,FRAC,(1<<52),0x3ff0000000000000,0x3fefffffffffffff,EXP-1,EXP] {for sb in 0..2 {check_nearest(a,bbase|(sb*SIGN),&mut checked);}}}}
 for _ in 0..200000 {let a=next(&mut state);let b=next(&mut state);if (a&EXP)!=EXP&&(b&EXP)!=EXP {check_nearest(a,b,&mut checked);}}
 println!("PASS {checked} additional nearest-helper checks, including subnormals, signed zeros, underflow and infinity");
}
fn same(a:u64,b:u64)->bool {a==b||((a&EXP==EXP)&&(a&FRAC!=0)&&(b&EXP==EXP)&&(b&FRAC!=0))}
fn check_nearest(a:u64,b:u64,count:&mut u64){
 let x=f64::from_bits(a);let y=f64::from_bits(b);let ox=F64::from_bits(a);let oy=F64::from_bits(b);let mode=OracleMode::TiesToEven;
 use compiler_builtins::float::{add::__adddf3,sub::__subdf3,mul::__muldf3,div::__divdf3};
 for (op,actual,expected) in [('+',__adddf3(x,y).to_bits(),ox.add(oy,mode).to_bits()),('-',__subdf3(x,y).to_bits(),ox.sub(oy,mode).to_bits()),('*',__muldf3(x,y).to_bits(),ox.mul(oy,mode).to_bits()),('/',__divdf3(x,y).to_bits(),ox.div(oy,mode).to_bits()),('s',libm::sqrt(x.abs()).to_bits(),F64::from_bits(a&!SIGN).sqrt(mode).to_bits())] {
 assert!(same(actual,expected),"nearest {op} {a:016x} {b:016x} actual={actual:016x} expected={expected:016x}");*count+=1;
 }
}
'''
(rp/'src/main.rs').write_text(main)
print('Pinned runtime helper probe written; directed arithmetic source unchanged except nearest-helper selection')
