from pathlib import Path
ROOT=Path('/root/experiment/randomx-sp1')
OUT=Path(__file__).parent/'float-probe'
(OUT/'src').mkdir(parents=True,exist_ok=True)
runtime=Path('/tmp/randomx-deep-review-_ic3s9ua/toolchain/library/compiler-builtins')
(OUT/'Cargo.toml').write_text(f'''[package]
name="focused-float-probe"
version="0.0.0"
edition="2021"
[workspace]
[lib]
crate-type=["cdylib"]
[dependencies]
randomx-softfp={{path="{ROOT/'softfp'}"}}
compiler_builtins={{path="{runtime/'builtins-shim'}",default-features=false,features=["mangled-names","no-asm","no-f16-f128"]}}
libm={{path="{runtime/'libm'}",default-features=false,features=["force-soft-floats"]}}
softfloat-wrapper="=0.3.4"
[profile.dev]
opt-level=2
overflow-checks=true
debug-assertions=true
''')
s=(ROOT/'softfp/src/lib.rs').read_text()
start=s.index('#[cfg(target_arch = "riscv64")]')
end=s.index('#[inline]\nfn add_inner',start)
nearest='''mod nearest {
    pub fn add(a:u64,b:u64)->u64 {compiler_builtins::float::add::__adddf3(f64::from_bits(a),f64::from_bits(b)).to_bits()}
    pub fn sub(a:u64,b:u64)->u64 {compiler_builtins::float::sub::__subdf3(f64::from_bits(a),f64::from_bits(b)).to_bits()}
    pub fn mul(a:u64,b:u64)->u64 {compiler_builtins::float::mul::__muldf3(f64::from_bits(a),f64::from_bits(b)).to_bits()}
    pub fn div(a:u64,b:u64)->u64 {compiler_builtins::float::div::__divdf3(f64::from_bits(a),f64::from_bits(b)).to_bits()}
    pub fn sqrt(a:u64)->u64 {libm::sqrt(f64::from_bits(a)).to_bits()}
}
'''
(OUT/'src/runtime.rs').write_text(s[:start]+nearest+s[end:])
(OUT/'src/lib.rs').write_text('''#[allow(dead_code)] mod runtime;
use softfloat_wrapper::{Float,F64,RoundingMode as O};
#[no_mangle]
pub extern "C" fn review_fp(variant:u32,op:u32,a:u64,b:u64,mode:u32)->u64 {
    if variant==0 {
        use randomx_softfp::*;
        let m=RoundingMode::from_fprc(mode);
        match op {0=>add(a,b,m),1=>sub(a,b,m),2=>mul(a,b,m),3=>div(a,b,m),4=>sqrt(a,m),_=>panic!()}
    } else if variant==1 {
        use runtime::*;
        let m=RoundingMode::from_fprc(mode);
        match op {0=>add(a,b,m),1=>sub(a,b,m),2=>mul(a,b,m),3=>div(a,b,m),4=>sqrt(a,m),_=>panic!()}
    } else {
        let x=F64::from_bits(a);let y=F64::from_bits(b);
        let m=match mode {0=>O::TiesToEven,1=>O::TowardNegative,2=>O::TowardPositive,3=>O::TowardZero,_=>panic!()};
        match op {0=>x.add(y,m),1=>x.sub(y,m),2=>x.mul(y,m),3=>x.div(y,m),4=>x.sqrt(m),_=>panic!()}.to_bits()
    }
}
''')
print('Prepared host floating-point library with debug assertions and overflow checks')
