"""Compare bit results with a separate unbounded-integer IEEE-754 model.
Skip exact nonzero results below the normal range: outside RandomX's domain.
Versions: repository host helper, pinned public Succinct helper source,
Berkeley SoftFloat. No Python floating-point arithmetic is used by the oracle.
"""
from pathlib import Path
from math import isqrt
import ctypes

SIGN=1<<63; FRAC=(1<<52)-1; INF=0x7ff0000000000000
lib=ctypes.CDLL(str(Path(__file__).parent/'float-probe/target/debug/libfocused_float_probe.so'))
call=lib.review_fp
call.argtypes=[ctypes.c_uint32,ctypes.c_uint32,ctypes.c_uint64,ctypes.c_uint64,ctypes.c_uint32]
call.restype=ctypes.c_uint64

def parts(bits):
    e=(bits>>52)&2047
    assert 0<e<2047 or bits&~SIGN==0
    return ((bits&FRAC)|(1<<52) if e else 0),e-1075 if e else -1074,bits>>63

def pack(q,e,negative,mode):
    if q>=1<<53: q>>=1;e+=1
    if e>1023:
        magnitude=INF if mode==0 or (mode==1 and negative) or (mode==2 and not negative) else INF-1
    else: magnitude=((e+1023)<<52)|(q&FRAC)
    return magnitude|(negative<<63)

def rounded(n,d,scale,negative,mode):
    if not n:return negative<<63
    e=n.bit_length()-d.bit_length()
    if (n<d<<e) if e>=0 else (n<<-e<d):e-=1
    e+=scale
    if e < -1022:return None
    shift=scale-e+52
    if shift>=0:n<<=shift
    else:d<<=-shift
    q,r=divmod(n,d)
    if mode==0:up=2*r>d or (2*r==d and q&1)
    else:up=r!=0 and ((mode==1 and negative) or (mode==2 and not negative))
    return pack(q+bool(up),e,negative,mode)

def exact(op,a,b,mode):
    ca,sa,na=parts(a);cb,sb,nb=parts(b)
    if op in (0,1):
        nb^=op;scale=min(sa,sb)
        n=((-ca if na else ca)<<(sa-scale))+((-cb if nb else cb)<<(sb-scale))
        negative=int(n<0) if n else na if na==nb else int(mode==1)
        return rounded(abs(n),1,scale,negative,mode)
    if op==2:return rounded(ca*cb,1,sa+sb,na^nb,mode)
    if op==3:
        if cb==0:return None
        return rounded(ca,cb,sa-sb,na^nb,mode)
    assert not na or ca==0
    if not ca:return na<<63
    e=(ca.bit_length()-1+sa)//2
    shift=sa-2*(e-52)
    assert shift>=0
    rad=ca<<shift;q=isqrt(rad);r=rad-q*q
    if mode==0:up=4*rad>(2*q+1)**2 or (4*rad==(2*q+1)**2 and q&1)
    else:up=mode==2 and r!=0
    return pack(q+bool(up),e,0,mode)

count=0;skipped=0
def check(op,a,b):
    global count,skipped
    for mode in range(4):
        expected=exact(op,a,b,mode)
        if expected is None:skipped+=1;continue
        for version in range(3):
            actual=call(version,op,a,b,mode)
            assert actual==expected,(version,op,f'{a:016x}',f'{b:016x}',mode,f'{actual:016x}',f'{expected:016x}')
            count+=1

fractions=[0,1,2,(1<<51)-1,1<<51,FRAC-1,FRAC]
distances=[0,1,2,51,52,53,54,74,75,76,77]
for e in range(1,2047):
    for j,f in enumerate(fractions):
        a=(e<<52)|f|(((e+j)&1)<<63)
        check(4,a&~SIGN,0)
        for k,distance in enumerate(distances):
            eb=e-distance
            if eb<1:continue
            b=(eb<<52)|fractions[(j+k)%len(fractions)]|(((e+k)&1)<<63)
            for op in range(4):check(op,a,b)
    if e%256==0:print(f'checked exponent {e}; {count} bit comparisons',flush=True)

# Explicit cancellation, signed zeros, and widely separated scales.
for e in [1,3,15,16,768,955,970,1022,1023,1024,1054,1455,2046]:
    for f in fractions:
        for s in [0,SIGN]:
            a=s|(e<<52)|f
            for b in [0,SIGN,a,a^SIGN,0x3ff0000000000000,0xbff0000000000000,0x7fefffffffffffff]:
                for op in range(4):check(op,a,b)
for a in [0,SIGN]:
    for b in [0,SIGN]:
        for op in [0,1,2,4]:check(op,a,b)

# Infinity is reachable in E. Its other operand is positive, finite, nonzero.
for b in [3<<52,768<<52,0x3ff0000000000000,0x41efffffffffffff]:
    for op in [2,3,4]:
        for mode in range(4):
            for version in range(3):
                assert call(version,op,INF,b,mode)==INF
                count+=1
print(f'PASS: {count} exact-integer bit comparisons across repository, pinned-runtime and Berkeley implementations; {skipped} per-mode out-of-domain/zero-divisor cases skipped',flush=True)
