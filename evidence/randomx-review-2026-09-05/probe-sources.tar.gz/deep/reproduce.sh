#!/usr/bin/env bash
set -euo pipefail
review_dir=/tmp/randomx-deep-review-_ic3s9ua
canonical_dir=/tmp/randomx-canonical-review-cgtbetcx/RandomX
canonical_build=/tmp/randomx-canonical-review-cgtbetcx/build

# Uses the canonical RandomX library built in the preceding host-only review.
# No SP1 guest, SP1 executor or prover build is invoked here.
c++ -O2 -std=c++11 -fPIC -fvisibility=hidden -shared "$review_dir/deep-shim.cpp" -I "$canonical_dir/src" -L "$canonical_build" -Wl,-rpath,"$canonical_build" -lrandomx -o "$review_dir/librxdeep.so"
cc -O2 -fPIC -fvisibility=hidden -shared "$review_dir/argon-shim.c" -I "$canonical_dir/src" -L "$canonical_build" -Wl,-rpath,"$canonical_build" -lrandomx -o "$review_dir/librxargon_deep.so"
c++ -O2 -std=c++11 -fPIC -fvisibility=hidden -shared "$review_dir/loop-shim.cpp" -I "$canonical_dir/src" -L "$canonical_build" -Wl,-rpath,"$canonical_build" -lrandomx -o "$review_dir/librxloop_deep.so"

cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --bin superscalar > "$review_dir/superscalar.log" 2>&1
cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --features compact-superscalar --bin superscalar_production > "$review_dir/superscalar-compact.log" 2>&1
cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --features unchecked-superscalar --bin superscalar_production > "$review_dir/superscalar-unchecked.log" 2>&1
cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --bin argon > "$review_dir/argon.log" 2>&1
cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --bin integer > "$review_dir/integer.log" 2>&1
cargo run --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --bin vm_loop > "$review_dir/vm-loop.log" 2>&1
RUSTC_BOOTSTRAP=1 cargo run --manifest-path "$review_dir/runtime-probe/Cargo.toml" --release --offline > "$review_dir/runtime.log" 2>&1
python3 "$review_dir/float-domain-bound.py" > "$review_dir/float-domain-bound.log" 2>&1

# Negative control: the old-bug copy must differ. Build failure is not a pass.
cargo build --manifest-path "$review_dir/probe/Cargo.toml" --release --offline --no-default-features --bin superscalar_old
if "$review_dir/probe/target/release/superscalar_old" > "$review_dir/superscalar-old.log" 2>&1; then
    echo 'ERROR: old-bug negative control unexpectedly passed' >&2
    exit 1
fi
rg 'program seed=283a6d78569c2e2b mode=1 byte=Some\(513\)' "$review_dir/superscalar-old.log"
