
#include <cstring>
#include "soft_aes.h"
extern "C" void rx_aes_round(int decrypt, const unsigned char* state, const unsigned char* key, unsigned char* out) {
 rx_vec_i128 s,k; memcpy(&s,state,16);memcpy(&k,key,16);
 auto result=decrypt ? soft_aesdec(s,k) : soft_aesenc(s,k);
 memcpy(out,&result,16);
}
