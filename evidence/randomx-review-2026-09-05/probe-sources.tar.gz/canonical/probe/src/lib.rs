
use std::ffi::c_void;
unsafe extern "C" {
 pub fn rx_generator_new(seed:*const u8,len:usize,nonce:u32)->*mut c_void;
 pub fn rx_generator_free(p:*mut c_void);
 pub fn rx_generator_next(p:*mut c_void,word:i32)->u32;
 pub fn rx_superscalar(p:*mut c_void,out:*mut u8,metrics:*mut i32,regs:*mut u64);
 pub fn rx_aes(kind:i32,state:*mut u8,bytes:usize,out:*mut u8);
 pub fn rx_step_new()->*mut c_void;
 pub fn rx_step_free(p:*mut c_void);
 pub fn rx_step(p:*mut c_void,raw:u64,index:i32,regs:*mut u8,scratch:*mut u8,masks:*const u64,mode:*mut u32,pc:*mut i32,target:*mut i32);
 pub fn rx_cache_new(key:*const u8,len:usize)->*mut c_void;
 pub fn rx_cache_free(p:*mut c_void);
 pub fn rx_cache_digest(p:*mut c_void,out:*mut u8);
 pub fn rx_dataset(p:*mut c_void,item:u64,out:*mut u8);
 pub fn rx_hash(p:*mut c_void,blob:*const u8,len:usize,out:*mut u8);
}
pub fn next(s:&mut u64)->u64 { *s=s.wrapping_add(0x9e3779b97f4a7c15); let mut z=*s; z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9); z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb); z^(z>>31) }
pub fn hex(x:&[u8])->String { x.iter().map(|b|format!("{b:02x}")).collect() }
