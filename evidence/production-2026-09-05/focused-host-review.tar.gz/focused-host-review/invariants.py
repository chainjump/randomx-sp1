"""Integer-only range checks supporting the manual source review.
The Argon calculation checks all block positions and an interval containing
every possible 32-bit pseudo-random choice, not a sample of RNG outputs.
The F calculation overapproximates all effects with exact outward rounding.
"""
L=262144; S=L//4; TWO32=1<<32
positions=0
for first in [True,False]:
    for segment in range(4):
        start=segment*S
        for current in range(start+(2 if first and segment==0 else 0),start+S):
            i=current-start
            area=current-1 if first else L-S+i-1
            assert 0<area<L
            # For any p in 0..2^32-1, t=floor(p*p/2^32) is monotone and
            # spans [0,2^32-2]. The second multiplication also fits in u64.
            tmax=((TWO32-1)**2)>>32
            assert tmax==TWO32-2 and area*tmax<1<<64
            rlo=area-1-((area*tmax)>>32);rhi=area-1
            assert 0<=rlo<=rhi<area
            base=0 if first or segment==3 else (segment+1)*S
            lo=base+rlo;hi=base+rhi
            intervals=[(lo,hi)] if hi<L else [(lo,L-1),(0,hi-L)]
            previous=(current-1)&(L-1)
            assert previous!=current
            for low,high in intervals:
                assert 0<=low<=high<L
                assert not low<=current<=high
                if first:assert high<current
            if first:assert previous<current
            positions+=1
print(f'PASS: initialization and non-aliasing bounds at all {positions} first/later-pass block positions, covering every pseudo-random word',flush=True)

FRAC=(1<<52)-1;ADD=1<<(32+1074)
def units(bits):
    e=bits>>52
    return bits if e==0 else ((1<<52)|(bits&FRAC))<<(e-1)

def rounded_units(n,up):
    if n<=0:return 0
    if n.bit_length()<=52:return n
    shift=n.bit_length()-53;q=n>>shift
    if up and n!=(q<<shift):q+=1
    if q==1<<53:q>>=1;shift+=1
    return ((shift+1)<<52)|(q&FRAC)

def insert(state,lo,hi):
    for e in range(lo>>52,(hi>>52)+1):
        low=max(lo,e<<52);high=min(hi,(e<<52)|FRAC)
        if e in state:low=min(low,state[e][0]);high=max(high,state[e][1])
        state[e]=(low,high)

state={};insert(state,0,(1023+31)<<52)
for step in range(1,769):
    out={}
    # Monotone addition endpoints, outward-rounded using unbounded integers.
    # Merge adjacent input intervals only to reduce work, not change the set.
    merged=[]
    for lo,hi in sorted(state.values()):
        if merged and lo<=merged[-1][1]+1:merged[-1]=(merged[-1][0],max(hi,merged[-1][1]))
        else:merged.append((lo,hi))
    for lo,hi in merged:insert(out,rounded_units(units(lo)-ADD,False),rounded_units(units(hi)+ADD,True))
    for e,(lo,hi) in state.items():
        insert(out,((e^15)<<52)|(lo&FRAC),((e^15)<<52)|(hi&FRAC))
    assert max(out)<2047,(step,max(out))
    state=out
    if step in [1,16,256,512,768]:
        upper=max(hi for lo,hi in state.values())
        print(f'F bound after {step} effects: bits=0x{upper:016x}, exponent={(upper>>52)-1023}',flush=True)
print('PASS: integer-only outward interval calculation excludes F infinity and NaN throughout all <=768-effect sequences',flush=True)

# u128 arithmetic bound in the addition fast path; multiplication comparison
# products have at most 106 bits. For normal nearby results, the alignment
# shifts for mul/div/sqrt are <=54; the wide side already occupies <=107 bits.
assert ((1<<53)-1)*(1<<75)+((1<<53)-1)<1<<128
assert ((1<<53)-1)**2<1<<106
assert -255-3*255 == -1020 and -1020>-1022
print('PASS: coefficient/product limits and conservative E lower bound',flush=True)
