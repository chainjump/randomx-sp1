#[path="/root/experiment/randomx-sp1/randomx-core/src/m128.rs"]
#[allow(dead_code)] mod m128;
#[path="/root/experiment/randomx-sp1/randomx-core/src/hash.rs"]
#[allow(dead_code)] mod hash;
fn main() { let _ = hash::hash_aes_1rx4(&[0u64; 8]); }
