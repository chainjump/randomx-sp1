use randomx_softfp::{add, sub, mul, div, sqrt, RoundingMode};
use softfloat_wrapper::{Float, F64, RoundingMode as OracleMode};
const SIGN: u64 = 1 << 63;
const EXP: u64 = 0x7ff0_0000_0000_0000;
const FRAC: u64 = 0x000f_ffff_ffff_ffff;
const MODES: [(RoundingMode, OracleMode); 4] = [
    (RoundingMode::Nearest, OracleMode::TiesToEven),
    (RoundingMode::Down, OracleMode::TowardNegative),
    (RoundingMode::Up, OracleMode::TowardPositive),
    (RoundingMode::TowardZero, OracleMode::TowardZero),
];
fn check_pair(a: u64, b: u64, checked: &mut u64) {
    let oa = F64::from_bits(a);
    let ob = F64::from_bits(b);
    for (mode, omode) in MODES {
        for (op, expected) in [
            ('+', oa.add(ob, omode).to_bits()),
            ('-', oa.sub(ob, omode).to_bits()),
            ('*', oa.mul(ob, omode).to_bits()),
            ('/', oa.div(ob, omode).to_bits()),
        ] {
            // Underflow and subnormal results are outside this crate's contract.
            if expected & EXP == 0 {
                if expected & !SIGN != 0 || matches!(op, '*' | '/') { continue; }
            }
            let actual = match op {
                '+' => add(a, b, mode), '-' => sub(a, b, mode),
                '*' => mul(a, b, mode), '/' => div(a, b, mode), _ => unreachable!(),
            };
            assert_eq!(actual, expected, "{op} a={a:016x} b={b:016x} {mode:?}");
            *checked += 1;
        }
    }
}
fn check_sqrt(a: u64, checked: &mut u64) {
    let a = a & !SIGN;
    let oa = F64::from_bits(a);
    for (mode, omode) in MODES {
        assert_eq!(sqrt(a, mode), oa.sqrt(omode).to_bits(), "sqrt a={a:016x} {mode:?}");
        *checked += 1;
    }
    // Force libm's portable implementation, as used by the SP1 soft-float target.
    assert_eq!(libm::sqrt(f64::from_bits(a)).to_bits(), oa.sqrt(OracleMode::TiesToEven).to_bits(), "portable sqrt a={a:016x}");
    *checked += 1;
}
fn next(state: &mut u64) -> u64 {
    *state ^= *state >> 12; *state ^= *state << 25; *state ^= *state >> 27;
    *state = state.wrapping_mul(0x2545_f491_4f6c_dd1d);
    *state
}
fn main() {
    let mut boundaries = Vec::new();
    for exponent in [1, 15, 16, 255, 511, 512, 700, 768, 960, 970, 971, 972, 995, 996, 997, 1022, 1023, 1024, 1030, 1040, 1054, 1299, 1500, 2044, 2045, 2046] {
        for fraction in [0, 1, 2, (1 << 51) - 1, 1 << 51, FRAC - 1, FRAC] {
            for sign in [0, SIGN] { boundaries.push(sign | exponent << 52 | fraction); }
        }
    }
    let mut checked = 0;
    for &a in &boundaries {
        check_sqrt(a, &mut checked);
        for &b in &boundaries { check_pair(a, b, &mut checked); }
    }
    let mut state = 0x3c6e_f372_fe94_f82b;
    for _ in 0..100_000 {
        let a = (next(&mut state) & (SIGN | FRAC)) | ((1 + next(&mut state) % 2046) << 52);
        let b = (next(&mut state) & (SIGN | FRAC)) | ((1 + next(&mut state) % 2046) << 52);
        check_pair(a, b, &mut checked);
        check_sqrt(a, &mut checked);
    }
    println!("{checked} arithmetic comparisons passed (targeted boundaries and 100000 random pairs).");
}
