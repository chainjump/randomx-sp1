from pathlib import Path
p=Path('/tmp/randomx-deep-review-_ic3s9ua'); repo=Path('/root/experiment/randomx-sp1')
(p/'argon-shim.c').write_text(r'''
#include "argon2_ref.c"
#define EXPORTED __attribute__((visibility("default")))
void rxa2_initial_hash(uint8_t*,argon2_context*,argon2_type);
EXPORTED void deep_argon_block(const uint64_t* prev,const uint64_t* ref,uint64_t* next,int with_xor){fill_block((const block*)prev,(const block*)ref,(block*)next,with_xor);}
EXPORTED uint32_t deep_argon_index(uint32_t pass,uint32_t slice,uint32_t index,uint32_t pseudo){argon2_instance_t inst={0};inst.lane_length=262144;inst.segment_length=65536;inst.lanes=1;argon2_position_t pos={pass,0,slice,index};return randomx_argon2_index_alpha(&inst,&pos,pseudo,1);}
EXPORTED void deep_argon_initial(const uint8_t* key,size_t length,uint8_t* out){argon2_context ctx={0};ctx.lanes=1;ctx.outlen=0;ctx.m_cost=262144;ctx.t_cost=3;ctx.version=0x13;ctx.pwd=(uint8_t*)key;ctx.pwdlen=length;ctx.salt=(uint8_t*)"RandomX\x03";ctx.saltlen=8;rxa2_initial_hash(out,&ctx,Argon2_d);}
EXPORTED int deep_hprime(uint8_t* out,size_t outlen,const uint8_t* in,size_t inlen){return blake2b_long(out,outlen,in,inlen);}
''')
src=(repo/'argon2/src/core.rs').read_text()
formula=src[src.index('        let reference_area_size ='):src.index('        debug_assert_ne!(prev_offset')]
append=r'''
pub fn review_compress<const WITH_XOR:bool>(prev:&[u64;128],reference:&[u64;128],old:&[u64;128])->[u64;128]{
 let mut next=core::mem::MaybeUninit::<[u64;128]>::uninit();
 if WITH_XOR {next.write(*old);}
 unsafe {fill_block_raw::<WITH_XOR>(&*(prev as *const _ as *const Block),&*(reference as *const _ as *const Block),next.as_mut_ptr().cast()); next.assume_init()}
}
pub fn review_initial(key:&[u8])->[u8;72]{initial_hash(key)}
pub fn review_hprime(out:&mut[u8],input:&[u8]){hprime(out,input)}
pub fn review_index<const FIRST_PASS:bool,const SLICE:u32>(index_in_segment:u32,pseudo_rand:u64)->usize{
 const LANE_LENGTH:u32=262144;const SEGMENT_LENGTH:u32=65536;const LANE_MASK:u32=LANE_LENGTH-1;
 let curr_offset=SLICE*SEGMENT_LENGTH+index_in_segment;
'''+formula+'\n ref_offset\n}\n'
(p/'probe/src/argon_core.rs').write_text(src+append)
(p/'probe/src/bin/argon.rs').write_text(r'''
#![allow(dead_code)]
#[path="/root/experiment/randomx-sp1/argon2/src/block.rs"] mod block;
#[path="/root/experiment/randomx-sp1/argon2/src/common.rs"] mod common;
#[path="../argon_core.rs"] mod argon_core;
#[link(name="rxargon_deep")]
unsafe extern "C" {
 fn deep_argon_block(prev:*const u64,reference:*const u64,next:*mut u64,with_xor:i32);
 fn deep_argon_index(pass:u32,slice:u32,index:u32,pseudo:u32)->u32;
 fn deep_argon_initial(key:*const u8,length:usize,out:*mut u8);
 fn deep_hprime(out:*mut u8,outlen:usize,input:*const u8,inlen:usize)->i32;
}
fn next(s:&mut u64)->u64{*s=s.wrapping_add(0x9e3779b97f4a7c15);let mut z=*s;z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9);z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb);z^(z>>31)}
fn main(){
 let mut rng=0x124093791284ac18;let mut blocks=0;
 for case in 0..24576 {
  let mut prev=[0;128]; let mut reference=[0;128]; let mut old=[0;128];
  for i in 0..128 {old[i]=next(&mut rng);}
  if case<8192 {prev[case/64]=1<<(case%64);}
  else if case<16384 {prev.fill(u64::MAX);prev[(case-8192)/64]^=1<<(case%64);}
  else {for i in 0..128 {prev[i]=next(&mut rng);reference[i]=next(&mut rng);}}
  if case%16==0 {reference=prev;}
  for xor in [false,true] {
   let mut expected=old;
   unsafe {deep_argon_block(prev.as_ptr(),reference.as_ptr(),expected.as_mut_ptr(),xor as i32);}
   let actual=if xor {argon_core::review_compress::<true>(&prev,&reference,&old)} else {argon_core::review_compress::<false>(&prev,&reference,&old)};
   assert_eq!(actual,expected,"block case={case} xor={xor}");blocks+=1;
  }
 }
 println!("PASS {blocks} Argon compression cases (including uninitialized Rust destinations on first pass)");
 let mut indices=0u64;
 for pass in 0..3 {for slice in 0..4 {for index in if pass==0&&slice==0 {2..65536} else {0..65536} {
  for pseudo in [0,1,u32::MAX,u32::MAX-1,0x80000000,0x7fffffff,0x10000,0xffff,next(&mut rng) as u32,next(&mut rng) as u32] {
   macro_rules! idx {($first:literal)=>{match slice {0=>argon_core::review_index::<$first,0>(index,pseudo as u64),1=>argon_core::review_index::<$first,1>(index,pseudo as u64),2=>argon_core::review_index::<$first,2>(index,pseudo as u64),_=>argon_core::review_index::<$first,3>(index,pseudo as u64)}}}
   let actual=if pass==0 {idx!(true)}else{idx!(false)};
   let expected=unsafe{deep_argon_index(pass,slice,index,pseudo)} as usize;
   assert_eq!(actual,expected,"index pass={pass} slice={slice} index={index} pseudo={pseudo}");
   let current=(slice*65536+index) as usize;
   assert!(actual<262144&&actual!=current);
   if pass==0 {assert!(actual<current);}
   indices+=1;
  }
 }}}
 println!("PASS {indices} Argon reference indices covering every block position in all three passes");
 for len in 0..=4096 {let key:Vec<u8>=(0..len).map(|_|next(&mut rng) as u8).collect();let mut expected=[0u8;72];unsafe{deep_argon_initial(key.as_ptr(),key.len(),expected.as_mut_ptr());}assert_eq!(argon_core::review_initial(&key),expected,"initial keylen={len}");}
 println!("PASS 4097 Argon initial hashes, key lengths 0 through 4096");
 let mut primes=0;
 for ilen in [0,1,7,8,63,64,65,71,72,73,127,128,129,255,256] {
  let input:Vec<u8>=(0..ilen).map(|_|next(&mut rng) as u8).collect();
  for olen in 1..=2048 {let mut expected=vec![0u8;olen];assert_eq!(unsafe{deep_hprime(expected.as_mut_ptr(),olen,input.as_ptr(),ilen)},0);let mut actual=vec![0u8;olen];argon_core::review_hprime(&mut actual,&input);assert_eq!(actual,expected,"hprime ilen={ilen} olen={olen}");primes+=1;}
 }
 println!("PASS {primes} Argon H-prime cases, output lengths 1 through 2048");
}
''')
print('Argon probe generated; original core source is an unchanged prefix')
