
#include <cstring>
#include <cstdint>
#include "bytecode_machine.hpp"
#include "superscalar.hpp"
#include "aes_hash.hpp"
#include "dataset.hpp"
#include "randomx.h"
#include "blake2/blake2.h"
using namespace randomx;
static_assert(sizeof(Instruction)==8, "instruction layout");
static_assert(sizeof(NativeRegisterFile)==256, "register layout");
struct StepContext { NativeRegisterFile reg; BytecodeMachine machine; };
struct HashContext { randomx_cache* cache; randomx_vm* vm; };
extern "C" {
void* rx_generator_new(const uint8_t* seed, size_t len, uint32_t nonce) { return new Blake2Generator(seed,len,(int)nonce); }
void rx_generator_free(void* p) { delete (Blake2Generator*)p; }
uint32_t rx_generator_next(void* p, int word) { return word ? ((Blake2Generator*)p)->getUInt32() : ((Blake2Generator*)p)->getByte(); }
void rx_superscalar(void* p, uint8_t* out, int32_t* metrics, uint64_t* regs) {
  SuperscalarProgram prog{};
  generateSuperscalar(prog,*(Blake2Generator*)p);
  memcpy(out,prog.programBuffer,8*prog.size);
  int v[]={int(prog.size),prog.addrReg,prog.codeSize,prog.macroOps,prog.decodeCycles,prog.cpuLatency,prog.asicLatency,prog.mulCount};
  memcpy(metrics,v,sizeof(v));
  memcpy(metrics+8,prog.cpuLatencies,8*sizeof(int));
  memcpy(metrics+16,prog.asicLatencies,8*sizeof(int));
  executeSuperscalar(*(uint64_t(*)[8])regs,prog);
}
void rx_aes(int kind, uint8_t* state, size_t bytes, uint8_t* out) {
  // Canonical SSE load/store helpers require 16-byte alignment.
  alignas(16) uint8_t alignedState[64]; memcpy(alignedState,state,64);
  auto* alignedOut=(uint8_t*)aligned_alloc(16,bytes);
  if(kind==1) fillAes1Rx4<true>(alignedState,bytes,alignedOut);
  else if(kind==4) fillAes4Rx4<true>(alignedState,bytes,alignedOut);
  else { memcpy(alignedOut,out,bytes); hashAes1Rx4<true>(alignedOut,bytes,alignedState); }
  memcpy(state,alignedState,64); memcpy(out,alignedOut,bytes); free(alignedOut);
}
void* rx_step_new() { auto* p=new StepContext{}; p->machine.beginCompilation(p->reg); return p; }
void rx_step_free(void* p) { delete (StepContext*)p; }
void rx_step(void* p, uint64_t raw, int32_t index, uint8_t* regs, uint8_t* scratch, const uint64_t* masks, uint32_t* mode, int32_t* pc, int32_t* target) {
  auto* ctx=(StepContext*)p;
  if(index==0) ctx->machine.beginCompilation(ctx->reg);
  memcpy(&ctx->reg,regs,256);
  Instruction instr; memcpy(&instr,&raw,8);
  InstructionByteCode bc{};
  ctx->machine.compileInstruction(instr,index,bc);
  *target=bc.type==InstructionType::CBRANCH ? bc.target : INT32_MIN;
  ProgramConfiguration cfg{}; cfg.eMask[0]=masks[0]; cfg.eMask[1]=masks[1];
  unsigned saved=_mm_getcsr();
  rx_set_rounding_mode(*mode);
  BytecodeMachine::executeInstruction(bc,*pc,scratch,cfg);
  *mode=rx_get_rounding_mode();
  _mm_setcsr(saved);
  memcpy(regs,&ctx->reg,256);
}
void* rx_cache_new(const uint8_t* key,size_t len) {
  auto* cache=randomx_alloc_cache(RANDOMX_FLAG_DEFAULT);
  if(!cache) return nullptr;
  // Same initializer as the public C API; bypass its std::string key memoization.
  initCache(cache,key,len);
  auto* vm=randomx_create_vm(RANDOMX_FLAG_DEFAULT,cache,nullptr);
  if(!vm) {randomx_release_cache(cache); return nullptr;}
  return new HashContext{cache,vm};
}
void rx_cache_free(void* p) { auto* c=(HashContext*)p; randomx_destroy_vm(c->vm); randomx_release_cache(c->cache); delete c; }
void rx_cache_digest(void* p,uint8_t* out) { auto* c=(HashContext*)p; blake2b(out,32,c->cache->memory,CacheSize,nullptr,0); }
void rx_dataset(void* p,uint64_t item,uint8_t* out) { initDatasetItem(((HashContext*)p)->cache,out,item); }
void rx_hash(void* p,const uint8_t* blob,size_t len,uint8_t* out) { randomx_calculate_hash(((HashContext*)p)->vm,blob,len,out); }
}
