/// Exercises all pair handlers and register aliases under Miri.
pub fn focused_safety_probe() {
    let infos = [&ISUB_R,&IXOR_R,&IADD_RS,&IMUL_R,&IROR_C,&IADD_C7,&IXOR_C7,&IMULH_R,&ISMULH_R,&IMUL_RCP];
    fn decoded(info: &'static ScInstrInfo,dst:i32,src:i32) -> ScExecInstr {
        let mut instr=ScInstr::null();
        instr.info=info;instr.dst=dst;instr.src=src;instr.mod_v=12;instr.imm32=0xfffffffbu32;
        instr.reciprocal=randomx_reciprocal(instr.imm32 as u64);
        ScExecInstr::decode(&instr)
    }
    fn checked(ds:&mut [u64;8],i:&ScExecInstr) {
        let d=i.dst_offset as usize/8;let s=i.src_offset as usize/8;
        ds[d]=match i.opcode {
            ScExecOpcode::IsubR=>ds[d].wrapping_sub(ds[s]),
            ScExecOpcode::IxorR=>ds[d]^ds[s],
            ScExecOpcode::IaddRs=>ds[d].wrapping_add(ds[s]<<i.immediate),
            ScExecOpcode::ImulR=>ds[d].wrapping_mul(ds[s]),
            ScExecOpcode::IrorC=>ds[d].rotate_right(i.immediate as u32),
            ScExecOpcode::IaddC=>ds[d].wrapping_add(i.immediate),
            ScExecOpcode::IxorC=>ds[d]^i.immediate,
            ScExecOpcode::ImulhR=>mulh(ds[d],ds[s]),
            ScExecOpcode::IsmulhR=>smulh(ds[d],ds[s]),
            ScExecOpcode::ImulRcp=>ds[d].wrapping_mul(i.immediate),
        };
    }
    let mut count=0;
    for (x,&a) in infos.iter().enumerate() {
        for (y,&b) in infos.iter().enumerate() {
            for dst in 0..8 {for src in 0..8 {
                let mut first=decoded(a,dst,src);let second=decoded(b,src,dst);
                first.pair_handler_offset=((10*x+y)*std::mem::size_of::<PairHandler>()) as u16;
                let mut actual=[0,u64::MAX,1,1<<63,0x123456789abcdef,99,7,u64::MAX-1];
                let mut expected=actual;checked(&mut expected,&first);checked(&mut expected,&second);
                execute_compact_pair_unchecked(&mut actual,&first,&second);
                assert_eq!(actual,expected);count+=1;
            }}
        }
    }
    let mut generator=Blake2Generator::new(b"focused safety review",0);
    let mut p=ScProgram::generate(&mut generator);
    let mut generated=[3;8];p.execute(&mut generated);let _=p.address_register(&generated);
    for length in 0..=65 {
        p.exec=(0..length).map(|i| decoded(infos[i%10],(i%8) as i32,((i+1)%8) as i32)).collect();
        for pair in p.exec.chunks_exact_mut(2) {
            pair[0].pair_handler_offset=((pair[0].opcode as usize*10+pair[1].opcode as usize)*std::mem::size_of::<PairHandler>()) as u16;
        }
        let mut actual=[u64::MAX;8];let mut expected=actual;
        for instruction in &p.exec {checked(&mut expected,instruction);}
        p.execute(&mut actual);assert_eq!(actual,expected);
    }
    println!("PASS: {count} pairs covering all 100 handlers and all register alias pairs, one generated program, all chunk/tail lengths 0..65");
}
