/// Runs exact compression and allocation-view operations under Miri.
pub fn focused_safety_probe() {
    const N: usize = 16;
    let mut storage = Box::<[Block]>::new_uninit_slice(N);
    let raw = storage.as_mut_ptr().cast::<Block>();
    for i in 0..2 {
        let mut block = Block::zero();
        for (j,b) in block.as_u8_mut().iter_mut().enumerate() {
            *b = (j as u8).wrapping_mul(17).wrapping_add(i as u8);
        }
        unsafe { raw.add(i).write(block); }
    }
    for i in 2..N {
        let reference = if i%3 == 0 {i-1} else {0};
        if std::env::args().nth(1).as_deref()==Some("argon-negative-control") {
            // Deliberate harness-only violation: read the uninitialized
            // destination, to verify that Miri detects this failure mode.
            unsafe { fill_block_raw::<true>(&*raw.add(i-1), &*raw.add(reference), raw.add(i).cast()); }
        } else {
            unsafe { fill_block_raw::<false>(&*raw.add(i-1), &*raw.add(reference), raw.add(i).cast()); }
        }
    }
    let mut blocks = unsafe { storage.assume_init() };
    let raw = blocks.as_mut_ptr();
    for pass in 0..2 {
        for i in 0..N {
            let previous = (i+N-1)%N;
            let reference = if pass==0 {(i+7)%N} else {previous};
            unsafe { fill_block_raw::<true>(&*raw.add(previous), &*raw.add(reference), raw.add(i).cast()); }
        }
    }
    // Same flattening operation as mix_block_value, across Block boundaries.
    let words = blocks.as_ptr().cast::<u64>();
    for i in 0..N*128 {
        assert_eq!(unsafe{*words.add(i)}, blocks[i/128][i%128]);
    }
    for block in blocks.iter_mut() {
        assert_eq!(block.as_u8().len(),1024);
        let before=block[127];
        block.as_u8_mut()[1016..1024].copy_from_slice(&before.to_ne_bytes());
        assert_eq!(block[127],before);
    }
    println!("PASS: 14 uninitialized-destination compressions, 32 XOR-pass compressions, shared-input aliases, 2048 flat-word reads and Block byte views");
}
