
#include "argon2_ref.c"
#define EXPORTED __attribute__((visibility("default")))
void rxa2_initial_hash(uint8_t*,argon2_context*,argon2_type);
EXPORTED void deep_argon_block(const uint64_t* prev,const uint64_t* ref,uint64_t* next,int with_xor){fill_block((const block*)prev,(const block*)ref,(block*)next,with_xor);}
EXPORTED uint32_t deep_argon_index(uint32_t pass,uint32_t slice,uint32_t index,uint32_t pseudo){argon2_instance_t inst={0};inst.lane_length=262144;inst.segment_length=65536;inst.lanes=1;argon2_position_t pos={pass,0,slice,index};return randomx_argon2_index_alpha(&inst,&pos,pseudo,1);}
EXPORTED void deep_argon_initial(const uint8_t* key,size_t length,uint8_t* out){argon2_context ctx={0};ctx.lanes=1;ctx.outlen=0;ctx.m_cost=262144;ctx.t_cost=3;ctx.version=0x13;ctx.pwd=(uint8_t*)key;ctx.pwdlen=length;ctx.salt=(uint8_t*)"RandomX\x03";ctx.saltlen=8;rxa2_initial_hash(out,&ctx,Argon2_d);}
EXPORTED int deep_hprime(uint8_t* out,size_t outlen,const uint8_t* in,size_t inlen){return blake2b_long(out,outlen,in,inlen);}
