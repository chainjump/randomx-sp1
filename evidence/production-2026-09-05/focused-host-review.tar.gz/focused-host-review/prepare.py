from pathlib import Path
import shutil, hashlib, json

ROOT = Path('/root/experiment/randomx-sp1')
OUT = Path(__file__).parent
names = {'argon2':'randomx-sp1-argon2','randomx-core':'randomx-sp1-core','randomx-sp1':'randomx-sp1','softfp':'randomx-softfp'}
manifest = '''[workspace]
members=["argon2","randomx-core","randomx-sp1","softfp","probe"]
resolver="2"
[workspace.package]
version="0.0.0"
edition="2021"
rust-version="1.91"
license="MIT OR Apache-2.0"
publish=false
[workspace.dependencies]
blake2b_simd="=1.0.4"
strum={version="=0.24.1",features=["derive"]}
softfloat="=1.0.0"
randomx-sp1-argon2={path="argon2"}
randomx-sp1-core={path="randomx-core"}
randomx-sp1={path="randomx-sp1"}
randomx-softfp={path="softfp"}
'''
(OUT/'Cargo.toml').write_text(manifest)
hashes={}
for d,name in names.items():
    shutil.copytree(ROOT/d/'src',OUT/d/'src',dirs_exist_ok=True)
    for f in (ROOT/d/'src').glob('*.rs'):
        hashes[str(f.relative_to(ROOT))]=hashlib.sha256(f.read_bytes()).hexdigest()
    if d == 'softfp':
        text='''[package]
name="randomx-softfp"
version.workspace=true
edition.workspace=true
[dependencies]
softfloat.workspace=true
'''
    else:
        text=(ROOT/d/'Cargo.toml').read_text().split('[dev-dependencies]')[0]
    (OUT/d/'Cargo.toml').write_text(text)

# The only replacement in production source: Miri cannot execute the host's
# floating-point-control assembly. Keep the stored VM mode and all guest code.
p=OUT/'randomx-core/src/vm.rs'
s=p.read_text(); start=s.index('fn set_rounding_mode_env(mode: u32) {'); end=s.index('\n/// Restores',start)
s=s[:start]+'fn set_rounding_mode_env(mode: u32) { let _ = mode; }\n'+s[end:]
p.write_text(s)

for d,extra in [('argon2','argon_probe.rs'),('randomx-core','superscalar_probe.rs'),('randomx-sp1','vm_probe.rs')]:
    target=OUT/d/'src'/('core.rs' if d=='argon2' else 'superscalar.rs' if d=='randomx-core' else 'lib.rs')
    with target.open('a') as f: f.write('\n'+(OUT/extra).read_text())
with (OUT/'argon2/src/lib.rs').open('a') as f:
    f.write('\npub use crate::core::focused_safety_probe;\n')

(OUT/'probe/src').mkdir(parents=True,exist_ok=True)
(OUT/'probe/Cargo.toml').write_text('''[package]
name="focused-safety-probe"
version="0.0.0"
edition="2024"
[dependencies]
randomx-sp1-argon2.workspace=true
randomx-sp1-core.workspace=true
randomx-sp1.workspace=true
''')
(OUT/'probe/src/main.rs').write_text('''fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("argon" | "argon-negative-control") => randomx_sp1_argon2::focused_safety_probe(),
        Some("superscalar") => randomx_sp1_core::superscalar::focused_safety_probe(),
        Some("vm") => randomx_sp1::focused_safety_probe(),
        Some("branch") => randomx_sp1::focused_branch_probe(),
        _ => panic!("expected argon, superscalar or vm"),
    }
}
''')
(OUT/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Prepared isolated host-only workspace:',OUT)
