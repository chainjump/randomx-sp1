
#include "superscalar-review.cpp"
#include <cstring>
#define EXPORTED extern "C" __attribute__((visibility("default")))
using namespace randomx;
EXPORTED int deep_generate(uint64_t seed,uint32_t mode,uint8_t* out,int32_t* metrics,uint64_t* regs,uint64_t* counts){
 try {ReviewGenerator gen(seed,mode);SuperscalarProgram prog{};for(auto& x:review_events)x=0;generateSuperscalarReview(prog,gen);memcpy(out,prog.programBuffer,8*prog.size);int m[]={int(prog.size),prog.addrReg,prog.codeSize,prog.macroOps,prog.decodeCycles,prog.cpuLatency,prog.asicLatency,prog.mulCount};memcpy(metrics,m,sizeof(m));memcpy(metrics+8,prog.cpuLatencies,8*sizeof(int));memcpy(metrics+16,prog.asicLatencies,8*sizeof(int));executeSuperscalarReview(*(uint64_t(*)[8])regs,prog,nullptr);counts[0]=gen.calls;counts[1]=gen.bytes;counts[2]=gen.words;memcpy(counts+3,review_events,sizeof(review_events));return 0;}catch(...){return -1;}
}
EXPORTED int deep_schedule(uint32_t window,uint32_t width,uint32_t start,uint32_t dep,uint32_t p1,uint32_t p2,int dependent,int commit,uint8_t* after){
 ExecutionPort::type busy[CYCLE_MAP_SIZE][3];for(auto& row:busy)for(auto& port:row)port=ExecutionPort::P0;
 for(unsigned i=0;i<width;i++)for(unsigned j=0;j<3;j++)busy[start+i][j]=((window>>(3*i+j))&1)?ExecutionPort::P0:ExecutionPort::Null;
 MacroOp base("review",3,1,(ExecutionPort::type)p1,(ExecutionPort::type)p2);MacroOp op(base,dependent);
 int result=commit?scheduleMop<true>(op,busy,start,dep):scheduleMop<false>(op,busy,start,dep);
 for(unsigned i=0;i<CYCLE_MAP_SIZE;i++)for(unsigned j=0;j<3;j++)after[3*i+j]=busy[i][j]!=ExecutionPort::Null;
 return result;
}
EXPORTED void deep_reciprocal(const uint32_t* divisors,uint64_t* results,size_t count){for(size_t i=0;i<count;i++)results[i]=randomx_reciprocal(divisors[i]);}
