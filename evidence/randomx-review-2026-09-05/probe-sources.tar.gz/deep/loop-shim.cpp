
#include <iostream>
#include <vector>
#include <new>
#include <cstring>
#include "virtual_machine.hpp"
#include "bytecode_machine.hpp"
#include "intrin_portable.h"
#include "allocator.hpp"
#define private public
#include "vm_interpreted.hpp"
#undef private
#define EXPORTED extern "C" __attribute__((visibility("default")))
using namespace randomx;
class LoopVm:public InterpretedVmDefault {
public:
 LoopVm(){scratchpad=(uint8_t*)AlignedAllocator<CacheLineSize>::allocMemory(ScratchpadSize);}
 void raw(const void* raw){memcpy(&program,raw,2176);initialize();execute();}
protected:
 void datasetPrefetch(uint64_t) override{}
 void datasetRead(uint64_t address,int_reg_t(&r)[RegistersCount]) override{
  // Same synthetic dataset as Rust VmMemory::no_memory; used solely to
  // isolate whole-iteration control/memory behavior from cache generation.
  uint64_t base=(address/64+1)*6364136223846793005ULL;
  uint64_t constants[]={0,9298411001130361340ULL,12065312585734608966ULL,9306329213124626780ULL,5281919268842080866ULL,10536153434571861004ULL,3398623926847679864ULL,9549104520008361294ULL};
  for(unsigned i=0;i<8;i++)r[i]^=base^constants[i];
 }
};
EXPORTED void* deep_loop_new(){return new LoopVm;}
EXPORTED void deep_loop_free(void* ptr){delete (LoopVm*)ptr;}
EXPORTED void deep_loop_run(void* ptr,const uint64_t* raw,uint8_t* scratch,uint8_t* regs,uint64_t* state,uint32_t* mode){
 auto* vm=(LoopVm*)ptr;auto saved=rx_get_rounding_mode();rx_set_rounding_mode(*mode);memcpy(vm->scratchpad,scratch,ScratchpadSize);vm->raw(raw);memcpy(scratch,vm->scratchpad,ScratchpadSize);memcpy(regs,&vm->reg,256);
 state[0]=vm->mem.mx;state[1]=vm->mem.ma;state[2]=vm->datasetOffset;state[3]=vm->config.readReg0;state[4]=vm->config.readReg1;state[5]=vm->config.readReg2;state[6]=vm->config.readReg3;state[7]=vm->config.eMask[0];state[8]=vm->config.eMask[1];*mode=rx_get_rounding_mode();rx_set_rounding_mode(saved);
}
