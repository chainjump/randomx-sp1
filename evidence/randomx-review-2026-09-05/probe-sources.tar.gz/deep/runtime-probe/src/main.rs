#[allow(dead_code)] mod softfp;
use softfp::{add, sub, mul, div, sqrt, RoundingMode};
use softfloat_wrapper::{Float, F64, RoundingMode as OracleMode};
const SIGN: u64 = 1 << 63;
const EXP: u64 = 0x7ff0_0000_0000_0000;
const FRAC: u64 = 0x000f_ffff_ffff_ffff;
const MODES: [(RoundingMode, OracleMode); 4] = [
    (RoundingMode::Nearest, OracleMode::TiesToEven),
    (RoundingMode::Down, OracleMode::TowardNegative),
    (RoundingMode::Up, OracleMode::TowardPositive),
    (RoundingMode::TowardZero, OracleMode::TowardZero),
];
fn check_pair(a: u64, b: u64, checked: &mut u64) {
    let oa = F64::from_bits(a);
    let ob = F64::from_bits(b);
    for (mode, omode) in MODES {
        for (op, expected) in [
            ('+', oa.add(ob, omode).to_bits()),
            ('-', oa.sub(ob, omode).to_bits()),
            ('*', oa.mul(ob, omode).to_bits()),
            ('/', oa.div(ob, omode).to_bits()),
        ] {
            // Underflow and subnormal results are outside this crate's contract.
            if expected & EXP == 0 {
                if expected & !SIGN != 0 || matches!(op, '*' | '/') { continue; }
            }
            let actual = match op {
                '+' => add(a, b, mode), '-' => sub(a, b, mode),
                '*' => mul(a, b, mode), '/' => div(a, b, mode), _ => unreachable!(),
            };
            assert_eq!(actual, expected, "{op} a={a:016x} b={b:016x} {mode:?}");
            *checked += 1;
        }
    }
}
fn check_sqrt(a: u64, checked: &mut u64) {
    let a = a & !SIGN;
    let oa = F64::from_bits(a);
    for (mode, omode) in MODES {
        assert_eq!(sqrt(a, mode), oa.sqrt(omode).to_bits(), "sqrt a={a:016x} {mode:?}");
        *checked += 1;
    }
    // Force libm's portable implementation, as used by the SP1 soft-float target.
    assert_eq!(libm::sqrt(f64::from_bits(a)).to_bits(), oa.sqrt(OracleMode::TiesToEven).to_bits(), "portable sqrt a={a:016x}");
    *checked += 1;
}
fn next(state: &mut u64) -> u64 {
    *state ^= *state >> 12; *state ^= *state << 25; *state ^= *state >> 27;
    *state = state.wrapping_mul(0x2545_f491_4f6c_dd1d);
    *state
}
fn main() {
    let mut boundaries = Vec::new();
    for exponent in [1, 15, 16, 255, 511, 512, 700, 768, 960, 970, 971, 972, 995, 996, 997, 1022, 1023, 1024, 1030, 1040, 1054, 1299, 1500, 2044, 2045, 2046] {
        for fraction in [0, 1, 2, (1 << 51) - 1, 1 << 51, FRAC - 1, FRAC] {
            for sign in [0, SIGN] { boundaries.push(sign | exponent << 52 | fraction); }
        }
    }
    let mut checked = 0;
    for &a in &boundaries {
        check_sqrt(a, &mut checked);
        for &b in &boundaries { check_pair(a, b, &mut checked); }
    }
    let mut state = 0x3c6e_f372_fe94_f82b;
    for _ in 0..100_000 {
        let a = (next(&mut state) & (SIGN | FRAC)) | ((1 + next(&mut state) % 2046) << 52);
        let b = (next(&mut state) & (SIGN | FRAC)) | ((1 + next(&mut state) % 2046) << 52);
        check_pair(a, b, &mut checked);
        check_sqrt(a, &mut checked);
    }
    println!("PASS {checked} arithmetic comparisons using pinned toolchain integer helpers and portable sqrt, all four rounding modes");
 nearest_checks();
}

fn nearest_checks(){
 let mut state=0xa780a269e4b31a10;let mut checked=0u64;
 let mut special=vec![0,1,2,FRAC-1,FRAC,1<<52,(1<<52)+1,EXP-2,EXP-1,EXP];
 for e in 1..2047 {for f in [0,1,FRAC] {special.push(e<<52|f);}}
 for s in 0..2 {for &base in &special {let a=base|(s*SIGN);for bbase in [0,1,FRAC,(1<<52),0x3ff0000000000000,0x3fefffffffffffff,EXP-1,EXP] {for sb in 0..2 {check_nearest(a,bbase|(sb*SIGN),&mut checked);}}}}
 for _ in 0..200000 {let a=next(&mut state);let b=next(&mut state);if (a&EXP)!=EXP&&(b&EXP)!=EXP {check_nearest(a,b,&mut checked);}}
 println!("PASS {checked} additional nearest-helper checks, including subnormals, signed zeros, underflow and infinity");
}
fn same(a:u64,b:u64)->bool {a==b||((a&EXP==EXP)&&(a&FRAC!=0)&&(b&EXP==EXP)&&(b&FRAC!=0))}
fn check_nearest(a:u64,b:u64,count:&mut u64){
 let x=f64::from_bits(a);let y=f64::from_bits(b);let ox=F64::from_bits(a);let oy=F64::from_bits(b);let mode=OracleMode::TiesToEven;
 use compiler_builtins::float::{add::__adddf3,sub::__subdf3,mul::__muldf3,div::__divdf3};
 for (op,actual,expected) in [('+',__adddf3(x,y).to_bits(),ox.add(oy,mode).to_bits()),('-',__subdf3(x,y).to_bits(),ox.sub(oy,mode).to_bits()),('*',__muldf3(x,y).to_bits(),ox.mul(oy,mode).to_bits()),('/',__divdf3(x,y).to_bits(),ox.div(oy,mode).to_bits()),('s',libm::sqrt(x.abs()).to_bits(),F64::from_bits(a&!SIGN).sqrt(mode).to_bits())] {
 assert!(same(actual,expected),"nearest {op} {a:016x} {b:016x} actual={actual:016x} expected={expected:016x}");*count+=1;
 }
}
