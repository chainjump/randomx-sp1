/// Exercises decoder-produced accesses without running a full RandomX hash.
pub fn focused_safety_probe() {
    let mut vm=new_vm(Arc::new(VmMemory::no_memory()));
    let mut count=0;
    for op in 0..256u64 {for dst in 0..8u64 {for src in 0..8u64 {
        let selector=(op+dst+src) as usize;
        let modifier=[0,1,3,0xe0,0xf0,0xff][selector%6];
        let immediate=[0,1,0x7fffffff,0x80000000,0xffffffff][selector%5];
        let raw=op|((dst+248)<<8)|((src+248)<<16)|(modifier<<24)|(immediate<<32);
        let mut usage=[-1;8];
        let instruction=decode_instruction(raw as i64,0,&mut usage);
        init_vm(&mut vm,&[u64::MAX;16]);
        vm.reg.r=[0,u64::MAX,1,u64::MAX-1,0x1ffff8,0x1fffc0,1<<63,63];
        vm.reg.f=[m128d::from_f64(-1.0,1.0);4];
        vm.reg.e=[m128d::from_f64(1.0,f64::from_bits(3<<52));4];
        vm.set_rounding_mode((selector%4) as u32);
        vm.pc=0;
        (instruction.effect)(&mut vm,&instruction);
        assert!((-1..=0).contains(&vm.pc));
        count+=1;
    }}}
    for offset in [0,8,SCRATCHPAD_L1_MASK as usize,SCRATCHPAD_L2_MASK as usize,SCRATCHPAD_L3_MASK as usize] {
        set_scratch_at_offset(&mut vm,offset,offset as u64);
        assert_eq!(scratch_at_offset(&vm,offset),offset as u64);
    }
    for base in [0,(SCRATCHPAD_L3_MASK_U32>>3) as usize] {for r in 0..8 {
        set_scratch(&mut vm,base+r,r as u64);
        assert_eq!(scratch(&vm,base+r),r as u64);
    }}
    // Decode an entire arbitrary-byte program and traverse its genuine branch
    // targets using the same fetch/effect/increment sequence as run().
    let bytes:Vec<_>=(0..136u64).map(|i|m128i::from_u64(i.wrapping_mul(0x9e3779b97f4a7c15),i.wrapping_mul(0xbf58476d1ce4e5b9))).collect();
    let p=CompactProgram::from_bytes(&bytes);
    init_vm(&mut vm,&p.entropy);
    vm.reg.f=[m128d::from_f64(-1.0,1.0);4];vm.reg.e=[m128d::from_f64(1.0,1.0);4];vm.pc=0;
    let mut effects=0;
    while vm.pc<PROGRAM_SIZE {
        assert!(vm.pc>=0);
        let instruction=unsafe{p.instructions.get_unchecked(vm.pc as usize)};
        (instruction.effect)(&mut vm,instruction);
        vm.pc+=1;effects+=1;assert!(effects<=768);
    }
    println!("PASS: {count} decoded instruction effects covering all opcode and reduced-register pairs, boundary scratchpad accesses, {effects} full-program instruction fetches");
}

/// Forces two taken backward branches, including target -1 and program exit.
pub fn focused_branch_probe() {
    let mut vm=new_vm(Arc::new(VmMemory::no_memory()));
    let nop=0x76u64; // ISWAP r0,r0 becomes a NOP and does not update usage.
    let mut bytes=vec![m128i::zero();136];
    for word in &mut bytes[8..] {*word=m128i::from_u64(nop,nop);}
    let branch=(0xffff_ffffu64<<32)|0xd6;
    bytes[135]=m128i::from_u64(branch,nop);
    let program=CompactProgram::from_bytes(&bytes);
    init_vm(&mut vm,&program.entropy);
    assert_eq!(program.instructions[255].target,-1);
    assert_eq!(program.instructions[255].imm,0u64.wrapping_sub(129));
    vm.reg.r[0]=258;
    vm.pc=0;
    let mut effects=0;let mut taken=0;
    while vm.pc<PROGRAM_SIZE {
        assert!(vm.pc>=0);
        let instruction=unsafe{program.instructions.get_unchecked(vm.pc as usize)};
        (instruction.effect)(&mut vm,instruction);
        if vm.pc==-1 {taken+=1;}
        vm.pc+=1;effects+=1;assert!(effects<=768);
    }
    assert_eq!(effects,768);assert_eq!(taken,2);assert_eq!(vm.pc,256);
    println!("PASS: 768 checked instruction fetches, two taken branches to target -1, termination at PC 256");
}
