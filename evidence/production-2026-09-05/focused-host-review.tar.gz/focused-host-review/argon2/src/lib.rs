// Copyright (c) 2017 Martijn Rijkeboer <mrr@sru-systems.com>
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

//! RandomX's fixed Argon2d v1.3 cache construction.
//!
//! This is deliberately not a general-purpose Argon2 or password-hashing API.
//! RandomX fixes the salt, memory size, lane count, iteration count, variant,
//! and version; callers provide only the RandomX key.

mod block;
mod common;
mod core;

pub use crate::block::Block;
pub use crate::core::initialize_randomx;

pub use crate::core::focused_safety_probe;
